# D0C-B0T
This program presents a series of questions to the patient, covering symptoms associated with depression, GAD, panic disorder, and SAD.
